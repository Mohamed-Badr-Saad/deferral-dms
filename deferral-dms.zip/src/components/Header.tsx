"use client";

import { UserMenu } from "@/src/components/UserMenu";

export function Header() {
  return (
    <header className="sticky top-0 z-10 border-b bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 w-full max-w-6xl items-center justify-between px-6">
        <div className="text-sm font-medium text-muted-foreground">
          Deferral Management System
        </div>
        <UserMenu />
      </div>
    </header>
  );
}
