import { db } from "@/src/db";
import { deferralApprovals, deferrals, notifications } from "@/src/db/schema";
import { and, asc, eq, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";

/**
 * Activate all approvals in the smallest step_order that still has PENDING approvals.
 * This is safer than "first row" because steps may be inserted later.
 */
export async function activateFirstPendingStep(deferralId: string) {
  const pending = await db
    .select()
    .from(deferralApprovals)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.status, "PENDING")
      )
    )
    .orderBy(asc(deferralApprovals.stepOrder));

  const first = pending[0];
  if (!first) return;

  await db
    .update(deferralApprovals)
    .set({ isActive: true } as any)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.stepOrder, first.stepOrder)
      )
    );
}

/**
 * Keep your old name for compatibility.
 */
export async function activateFirstStep(deferralId: string) {
  return activateFirstPendingStep(deferralId);
}

/**
 * Advance workflow when a step (or a member of a parallel step) is completed.
 * - Works with parallel steps (same step_order)
 * - Skips step_orders that only have SKIPPED/APPROVED/REJECTED
 * - Can recover if isActive flags were lost
 */
export async function afterApprovalAdvance(deferralId: string) {
  // Find current active step_order (lowest)
  const active = await db
    .select()
    .from(deferralApprovals)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.isActive, true)
      )
    )
    .orderBy(asc(deferralApprovals.stepOrder));

  // If no active steps, activate first pending step (recovery mode)
  if (active.length === 0) {
    await activateFirstPendingStep(deferralId);
    return;
  }

  const currentStepOrder = active[0].stepOrder;

  // If anything in the current step_order is still PENDING, we can't advance.
  const stillPending = await db
    .select()
    .from(deferralApprovals)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.stepOrder, currentStepOrder),
        eq(deferralApprovals.status, "PENDING")
      )
    );

  if (stillPending.length > 0) return;

  // Deactivate the current step_order
  await db
    .update(deferralApprovals)
    .set({ isActive: false } as any)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.stepOrder, currentStepOrder)
      )
    );

  // Find the next step_order that has any PENDING approvals
  const nextPending = await db
    .select()
    .from(deferralApprovals)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.status, "PENDING")
      )
    )
    .orderBy(asc(deferralApprovals.stepOrder));

  if (nextPending.length === 0) {
    // No pending left => completed workflow
    await db
      .update(deferrals)
      .set({ status: "COMPLETED", updatedAt: new Date() } as any)
      .where(eq(deferrals.id, deferralId));
    return;
  }

  const nextOrder = nextPending[0].stepOrder;

  // Activate all approvals in nextOrder (parallel support)
  await db
    .update(deferralApprovals)
    .set({ isActive: true } as any)
    .where(
      and(
        eq(deferralApprovals.deferralId, deferralId),
        eq(deferralApprovals.stepOrder, nextOrder)
      )
    );
}

export async function notifyUser(
  userId: string,
  title: string,
  body: string,
  deferralId?: string | null
) {
  await db.insert(notifications).values({
    id: randomUUID(),
    userId,
    deferralId: deferralId ?? null,
    title,
    body,
    isRead: false,
  } as any);
}
