import { betterAuth } from "better-auth";
import { nextCookies } from "better-auth/next-js";
import { Pool } from "pg";

export const auth = betterAuth({
  secret: process.env.BETTER_AUTH_SECRET!,
  database: new Pool({
    connectionString: process.env.DATABASE_URL,
  }),

  emailAndPassword: {
    enabled: true,
    requireEmailVerification: false,
    // DEFAULT: autoSignIn = true (keep it)
  },

  advanced: {
    database: {
      generateId: "uuid",
    },
  },

  plugins: [nextCookies()],
});
