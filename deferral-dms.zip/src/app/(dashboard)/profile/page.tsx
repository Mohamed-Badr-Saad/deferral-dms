"use client";

import { useEffect, useMemo, useState } from "react";
import { api } from "@/src/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SignatureCropDialog } from "@/src/components/profile/SignatureCropDialog";
import { toast } from "sonner";

type Profile = {
  id: string;
  email: string;
  name: string;
  department: string;
  position: string;
  role: string;
  signatureUrl?: string | null;
  signatureUploadedAt?: string | null;
};

export default function ProfilePage() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  const [rawImageSrc, setRawImageSrc] = useState<string | null>(null);
  const [cropOpen, setCropOpen] = useState(false);

  async function load() {
    setLoading(true);
    try {
      const res = await api<{ profile: Profile }>("/api/profile");
      setProfile(res.profile);
    } catch (e: any) {
      toast("Error", { description: e.message ?? "Failed to load profile" });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signatureInfo = useMemo(() => {
    if (!profile?.signatureUploadedAt) return "Not uploaded";
    return new Date(profile.signatureUploadedAt).toLocaleString();
  }, [profile?.signatureUploadedAt]);

  function onPickFile(file: File) {
    const url = URL.createObjectURL(file);
    setRawImageSrc(url);
    setCropOpen(true);
  }

  async function uploadCropped(blob: Blob) {
    const form = new FormData();
    form.append(
      "file",
      new File([blob], "signature.png", { type: "image/png" })
    );

    const res = await fetch("/api/profile/signature", {
      method: "POST",
      body: form,
    });
    const json = await res.json().catch(() => null);

    if (!res.ok) {
      toast("Upload failed", {
        description: json?.detail ?? json?.message ?? "Server error",
      });
      return;
    }

    toast("Saved", { description: "Your signature was updated." });
    await load();
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Profile</h1>
        <p className="text-sm text-muted-foreground">
          Manage your account and signature.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {loading || !profile ? (
            <div className="text-sm text-muted-foreground">Loading...</div>
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-xs text-muted-foreground">Name</div>
                <div className="font-medium">{profile.name}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Email</div>
                <div className="font-medium">{profile.email}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Department</div>
                <div className="font-medium">{profile.department}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Position</div>
                <div className="font-medium">{profile.position}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Role</div>
                <div className="font-medium">{profile.role}</div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <CardTitle>Signature</CardTitle>
          <div className="text-xs text-muted-foreground">
            Last upload: {signatureInfo}
          </div>
        </CardHeader>

        <CardContent className="space-y-4">
          <div className="rounded-lg border bg-white p-4">
            {profile?.signatureUrl ? (
              <img
                src={profile.signatureUrl}
                alt="signature"
                className="h-16 w-auto max-w-[360px] object-contain"
              />
            ) : (
              <div className="text-sm text-muted-foreground">
                No signature uploaded. Approvals will fall back to your name +
                date.
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label className="inline-flex">
              <input
                type="file"
                accept="image/png,image/jpeg"
                className="hidden"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) onPickFile(f);
                  e.currentTarget.value = "";
                }}
              />
              <Button asChild>
                <span>Upload & Trim</span>
              </Button>
            </label>

            <div className="text-xs text-muted-foreground">
              Upload an image, then crop tightly around the signature.
            </div>
          </div>
        </CardContent>
      </Card>

      {rawImageSrc && (
        <SignatureCropDialog
          open={cropOpen}
          onOpenChange={(v) => setCropOpen(v)}
          imageSrc={rawImageSrc}
          onCropped={uploadCropped}
        />
      )}
    </div>
  );
}
